"use strict";
// import { UserDatabase } from "../data/UserDatabase";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FileBusiness = void 0;
var FileBusiness = /** @class */ (function () {
    function FileBusiness() {
    }
    return FileBusiness;
}());
exports.FileBusiness = FileBusiness;
