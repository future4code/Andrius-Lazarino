"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PostOrderBy = exports.PostType = exports.Post = void 0;
var Post = /** @class */ (function () {
    function Post(id, image, description, type, idUser, createdAt) {
        this.id = id;
        this.image = image;
        this.description = description;
        this.type = type;
        this.idUser = idUser;
        this.createdAt = createdAt;
    }
    return Post;
}());
exports.Post = Post;
var PostType;
(function (PostType) {
    PostType["NORMAL"] = "normal";
    PostType["EVENT"] = "event";
})(PostType = exports.PostType || (exports.PostType = {}));
var PostOrderBy;
(function (PostOrderBy) {
    PostOrderBy["RECENT"] = "DESC";
    PostOrderBy["OLD"] = "ASC";
})(PostOrderBy = exports.PostOrderBy || (exports.PostOrderBy = {}));
